package com.meuprojeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TerceiroProjetoCrudThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
